1. To compile our AdaBoost face detector, use the command "make face".

2. To compile our AdaBoost dartboard detector, use the command "make dart".

3. To compile our combined Hough transform and Adaboost detector, use the command "make hough".

4. To compile our final classifier, use the command "make ellipse".

To run any of these detectors, use the command "./a.out FILENAME.jpg", where FILENAME.jpg
is the image you want to run the detector with.
